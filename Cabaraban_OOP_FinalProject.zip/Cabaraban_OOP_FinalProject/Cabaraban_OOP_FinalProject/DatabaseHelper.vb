﻿Imports System.Data
Imports System.IO

Public Class DatabaseHelper
    Private Shared dbPath As String = Path.Combine(Application.StartupPath, "GradeBookData.xml")

    Private Shared Function CreateTable() As DataTable
        Dim dt As New DataTable("StudentScores")
        dt.Columns.Add("StudentID", GetType(String))
        dt.Columns.Add("StudentName", GetType(String))
        dt.Columns.Add("CourseCode", GetType(String))
        dt.Columns.Add("QuizScore", GetType(Double))
        dt.Columns.Add("QuizMax", GetType(Double))
        dt.Columns.Add("ExamScore", GetType(Double))
        dt.Columns.Add("ExamMax", GetType(Double))
        dt.Columns.Add("ProjectScore", GetType(Double))
        dt.Columns.Add("ProjectMax", GetType(Double))

        Dim primaryKey(0) As DataColumn
        primaryKey(0) = dt.Columns("StudentID")
        dt.PrimaryKey = primaryKey

        Return dt
    End Function

    Public Shared Sub InitializeDatabase()
        If Not File.Exists(dbPath) Then
            Dim dt As DataTable = CreateTable()
            dt.WriteXml(dbPath, XmlWriteMode.WriteSchema)
        End If
    End Sub

    Public Shared Sub SaveOrUpdateStudent(ByVal id As String, ByVal name As String, ByVal course As String, _
                                          ByVal qScore As Double, ByVal qMax As Double, _
                                          ByVal eScore As Double, ByVal eMax As Double, _
                                          ByVal pScore As Double, ByVal pMax As Double)
        InitializeDatabase()
        Dim dt As DataTable = LoadAllStudents()

        Dim row As DataRow = dt.Rows.Find(id)
        If row IsNot Nothing Then
            row("StudentName") = name
            row("CourseCode") = course
            row("QuizScore") = qScore
            row("QuizMax") = qMax
            row("ExamScore") = eScore
            row("ExamMax") = eMax
            row("ProjectScore") = pScore
            row("ProjectMax") = pMax
        Else
            dt.Rows.Add(id, name, course, qScore, qMax, eScore, eMax, pScore, pMax)
        End If

        dt.WriteXml(dbPath, XmlWriteMode.WriteSchema)
    End Sub

    Public Shared Sub DeleteStudent(ByVal id As String)
        InitializeDatabase()
        Dim dt As DataTable = LoadAllStudents()

        Dim row As DataRow = dt.Rows.Find(id)
        If row IsNot Nothing Then
            dt.Rows.Remove(row)
            dt.WriteXml(dbPath, XmlWriteMode.WriteSchema)
        End If
    End Sub

    Public Shared Function LoadAllStudents() As DataTable
        InitializeDatabase()
        Dim dt As DataTable = CreateTable()
        If File.Exists(dbPath) Then
            dt.ReadXml(dbPath)
        End If
        Return dt
    End Function
End Class