﻿' Abstract Base Class
Public MustInherit Class Person
    Public Property ID As String
    Public Property Name As String

    Public Sub New(ByVal id As String, ByVal name As String)
        Me.ID = id
        Me.Name = name
    End Sub
End Class

' Derived Student Class
Public Class Student
    Inherits Person

    Public Property Course As String

    Public Sub New(ByVal id As String, ByVal name As String, ByVal course As String)
        MyBase.New(id, name)
        Me.Course = course
    End Sub
End Class