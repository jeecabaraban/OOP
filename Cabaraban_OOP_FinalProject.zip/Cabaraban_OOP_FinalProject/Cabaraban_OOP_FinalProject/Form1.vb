﻿Imports System.IO

Public Class Form1
    Private currentCourse As Course

    ' In-memory score record per student
    Private Class StudentScoreRecord
        Public Property QuizScore As Double
        Public Property QuizMax As Double
        Public Property ExamScore As Double
        Public Property ExamMax As Double
        Public Property ProjectScore As Double
        Public Property ProjectMax As Double
    End Class

    Private scoreDatabase As New Dictionary(Of String, StudentScoreRecord)()

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        currentCourse = New Course("CS-101", "Object-Oriented Programming")

        ' Initialize grids for Tab 1 and Tab 2
        SetupGrid(dgvLiveRoster)
        SetupDarkGrid()

        ' Initialize local XML database and load records
        DatabaseHelper.InitializeDatabase()
        LoadStudentsFromDatabase()
    End Sub

    Private Sub LoadStudentsFromDatabase()
        Dim dt As DataTable = DatabaseHelper.LoadAllStudents()

        ' Pre-populate default records if database file is completely empty
        If dt.Rows.Count = 0 Then
            AddOrUpdateStudentRecord("2026-0001", "Alice Smith", "CS-101", 30, 30, 48, 50, 19, 20)
            AddOrUpdateStudentRecord("2026-0002", "Honey Mae Ariola", "CS-101", 30, 30, 48, 50, 19, 20)
            AddOrUpdateStudentRecord("2026-0003", "Kirby Ann Franco", "CS-101", 22, 30, 38, 50, 15, 20)
            AddOrUpdateStudentRecord("2026-0004", "Felicity Jane Seiga", "CS-101", 15, 30, 28, 50, 10, 20)
            AddOrUpdateStudentRecord("2026-0005", "Jesilay Calbo", "CS-101", 27, 30, 43, 50, 18, 20)
            AddOrUpdateStudentRecord("2026-0006", "Harvey Alingasa", "CS-101", 18, 30, 32, 50, 12, 20)
            AddOrUpdateStudentRecord("2026-0007", "Jee Ann Cabaraban", "CS-101", 30, 30, 45, 50, 15, 20)
        Else
            For Each row As DataRow In dt.Rows
                AddOrUpdateStudentRecord( _
                    row("StudentID").ToString(), _
                    row("StudentName").ToString(), _
                    row("CourseCode").ToString(), _
                    Convert.ToDouble(row("QuizScore")), _
                    Convert.ToDouble(row("QuizMax")), _
                    Convert.ToDouble(row("ExamScore")), _
                    Convert.ToDouble(row("ExamMax")), _
                    Convert.ToDouble(row("ProjectScore")), _
                    Convert.ToDouble(row("ProjectMax")), _
                    False)
            Next
        End If
    End Sub

    Private Sub AddOrUpdateStudentRecord(ByVal id As String, ByVal name As String, ByVal courseCode As String, _
                                         ByVal qScore As Double, ByVal qMax As Double, _
                                         ByVal eScore As Double, ByVal eMax As Double, _
                                         ByVal pScore As Double, ByVal pMax As Double, _
                                         Optional ByVal saveToDb As Boolean = True)

        ' Save directly into local XML database file
        If saveToDb Then
            DatabaseHelper.SaveOrUpdateStudent(id, name, courseCode, qScore, qMax, eScore, eMax, pScore, pMax)
        End If

        ' Save raw scores into memory dictionary
        Dim rec As New StudentScoreRecord With { _
            .QuizScore = qScore, .QuizMax = qMax, _
            .ExamScore = eScore, .ExamMax = eMax, _
            .ProjectScore = pScore, .ProjectMax = pMax _
        }

        If scoreDatabase.ContainsKey(id.ToLower()) Then
            scoreDatabase(id.ToLower()) = rec
        Else
            scoreDatabase.Add(id.ToLower(), rec)
        End If

        ' Compute grades via OOP domain objects
        Dim student As New Student(id, name, courseCode)
        Dim studentGrade As New Grade(student)

        studentGrade.AddAssessment(New QuizAssessment(qScore, qMax, 30.0))
        studentGrade.AddAssessment(New ExamAssessment(eScore, eMax, 50.0))
        studentGrade.AddAssessment(New ProjectAssessment(pScore, pMax, 20.0))

        Dim finalNumeric As Double = studentGrade.ComputeFinal()
        Dim status As String = studentGrade.IsPassed(finalNumeric)
        Dim gradeFormatted As String = finalNumeric.ToString("0.00") & "%"

        ' Sync Tab 1 DataGridView
        Dim liveRow As DataGridViewRow = FindRowByID(dgvLiveRoster, id)
        If liveRow IsNot Nothing Then
            liveRow.Cells(0).Value = id
            liveRow.Cells(1).Value = name
            liveRow.Cells(2).Value = courseCode
            liveRow.Cells(3).Value = gradeFormatted
            liveRow.Cells(4).Value = status
        Else
            dgvLiveRoster.Rows.Add(id, name, courseCode, gradeFormatted, status)
        End If

        ' Sync Tab 2 DataGridView
        Dim darkRow As DataGridViewRow = FindRowByID(dgvDarkGrid, id)
        If darkRow IsNot Nothing Then
            darkRow.Cells(0).Value = id
            darkRow.Cells(1).Value = name
            darkRow.Cells(2).Value = courseCode
            darkRow.Cells(3).Value = gradeFormatted
            darkRow.Cells(4).Value = status
        Else
            dgvDarkGrid.Rows.Add(id, name, courseCode, gradeFormatted, status)
        End If

        ' Keep both tables automatically sorted alphabetically by Student Name (Column 1)
        dgvLiveRoster.Sort(dgvLiveRoster.Columns(1), System.ComponentModel.ListSortDirection.Ascending)
        dgvDarkGrid.Sort(dgvDarkGrid.Columns(1), System.ComponentModel.ListSortDirection.Ascending)
    End Sub

    ' --- HELPER PROCEDURES & GRID SETUP ---

    Private Function FindRowByID(ByVal dgv As DataGridView, ByVal id As String) As DataGridViewRow
        If dgv Is Nothing Then Return Nothing
        For Each row As DataGridViewRow In dgv.Rows
            If Not row.IsNewRow Then
                Dim rowID As String = If(row.Cells(0).Value IsNot Nothing, row.Cells(0).Value.ToString().Trim().ToLower(), "")
                If rowID = id.Trim().ToLower() Then Return row
            End If
        Next
        Return Nothing
    End Function

    Private Sub SetupGrid(ByVal dgv As DataGridView)
        dgv.ColumnCount = 5
        dgv.Columns(0).Name = "Student ID"
        dgv.Columns(1).Name = "Student Name"
        dgv.Columns(2).Name = "Course"
        dgv.Columns(3).Name = "Grade"
        dgv.Columns(4).Name = "Status"

        ' Allow clicking headers to sort
        For Each col As DataGridViewColumn In dgv.Columns
            col.SortMode = DataGridViewColumnSortMode.Automatic
        Next

        dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect
    End Sub

    Private Sub SetupDarkGrid()
        SetupGrid(dgvDarkGrid)

        dgvDarkGrid.DefaultCellStyle.ForeColor = Color.Black
        dgvDarkGrid.DefaultCellStyle.BackColor = Color.White

        If cmbStatusFilter.Items.Count = 0 Then
            cmbStatusFilter.Items.Add("All")
            cmbStatusFilter.Items.Add("PASSED")
            cmbStatusFilter.Items.Add("FAILED")
        End If
        cmbStatusFilter.SelectedIndex = 0
    End Sub

    ' --- TAB 1: SELECTION & FORM FILL ---

    Private Sub LoadStudentScoresToForm(ByVal studentID As String, ByVal studentName As String)
        txtStudentID.Text = studentID
        txtStudentName.Text = studentName

        Dim key As String = studentID.Trim().ToLower()
        If scoreDatabase.ContainsKey(key) Then
            Dim rec As StudentScoreRecord = scoreDatabase(key)
            txtQuizScore.Text = rec.QuizScore.ToString()
            txtQuizMax.Text = rec.QuizMax.ToString()
            txtExamScore.Text = rec.ExamScore.ToString()
            txtExamMax.Text = rec.ExamMax.ToString()
            txtProjectScore.Text = rec.ProjectScore.ToString()
            txtProjectMax.Text = rec.ProjectMax.ToString()
        End If
    End Sub

    Private Sub txtSearchRoster_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtSearchRoster.TextChanged
        Dim query As String = txtSearchRoster.Text.Trim().ToLower()
        dgvLiveRoster.ClearSelection()
        If query = "" Then Exit Sub

        For Each row As DataGridViewRow In dgvLiveRoster.Rows
            If Not row.IsNewRow Then
                Dim idVal As String = If(row.Cells(0).Value IsNot Nothing, row.Cells(0).Value.ToString().ToLower(), "")
                Dim nameVal As String = If(row.Cells(1).Value IsNot Nothing, row.Cells(1).Value.ToString().ToLower(), "")

                If idVal.Contains(query) OrElse nameVal.Contains(query) Then
                    row.Selected = True
                    dgvLiveRoster.FirstDisplayedScrollingRowIndex = row.Index
                    LoadStudentScoresToForm(row.Cells(0).Value.ToString(), row.Cells(1).Value.ToString())
                    Exit For
                End If
            End If
        Next
    End Sub

    Private Sub dgvLiveRoster_CellDoubleClick(ByVal sender As Object, ByVal e As DataGridViewCellEventArgs) Handles dgvLiveRoster.CellDoubleClick
        If e.RowIndex >= 0 AndAlso Not dgvLiveRoster.Rows(e.RowIndex).IsNewRow Then
            Dim row As DataGridViewRow = dgvLiveRoster.Rows(e.RowIndex)
            LoadStudentScoresToForm(row.Cells(0).Value.ToString(), row.Cells(1).Value.ToString())
        End If
    End Sub

    Private Sub btnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click
        If txtStudentID.Text.Trim() = "" Then
            MessageBox.Show("Please select or enter a Student ID first.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        Try
            Dim qScore As Double = Convert.ToDouble(If(txtQuizScore.Text = "", "0", txtQuizScore.Text))
            Dim qMax As Double = Convert.ToDouble(If(txtQuizMax.Text = "", "100", txtQuizMax.Text))
            Dim eScore As Double = Convert.ToDouble(If(txtExamScore.Text = "", "0", txtExamScore.Text))
            Dim eMax As Double = Convert.ToDouble(If(txtExamMax.Text = "", "100", txtExamMax.Text))
            Dim pScore As Double = Convert.ToDouble(If(txtProjectScore.Text = "", "0", txtProjectScore.Text))
            Dim pMax As Double = Convert.ToDouble(If(txtProjectMax.Text = "", "100", txtProjectMax.Text))

            AddOrUpdateStudentRecord(txtStudentID.Text.Trim(), txtStudentName.Text.Trim(), cmbCourse.Text, qScore, qMax, eScore, eMax, pScore, pMax)
            MessageBox.Show("Grade record re-computed and updated for " & txtStudentName.Text & "!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("Error processing scores: " & ex.Message, "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtStudentID.Clear()
        txtStudentName.Clear()
        txtQuizScore.Text = "0"
        txtExamScore.Text = "0"
        txtProjectScore.Text = "0"
        txtStudentID.Focus()
    End Sub

    ' --- TAB 2: ROBUST SEARCH & FILTER LOGIC ---

    Private Sub ApplyDarkGridFilter()
        Dim query As String = If(txtDarkSearch IsNot Nothing, txtDarkSearch.Text.Trim().ToLower(), "")

        Dim selectedStatus As String = "All"
        If cmbStatusFilter IsNot Nothing AndAlso cmbStatusFilter.SelectedItem IsNot Nothing Then
            Dim sel As String = cmbStatusFilter.SelectedItem.ToString().Trim()
            If sel <> "" Then selectedStatus = sel
        End If

        For Each row As DataGridViewRow In dgvDarkGrid.Rows
            If Not row.IsNewRow Then
                Dim idVal As String = If(row.Cells(0).Value IsNot Nothing, row.Cells(0).Value.ToString().ToLower(), "")
                Dim nameVal As String = If(row.Cells(1).Value IsNot Nothing, row.Cells(1).Value.ToString().ToLower(), "")
                Dim statusVal As String = If(row.Cells(4).Value IsNot Nothing, row.Cells(4).Value.ToString().Trim(), "")

                Dim matchesSearch As Boolean = (query = "" OrElse idVal.Contains(query) OrElse nameVal.Contains(query))
                Dim matchesStatus As Boolean = (selectedStatus.Equals("All", StringComparison.OrdinalIgnoreCase) OrElse statusVal.Equals(selectedStatus, StringComparison.OrdinalIgnoreCase))

                row.Visible = (matchesSearch AndAlso matchesStatus)
            End If
        Next
    End Sub

    Private Sub txtDarkSearch_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles txtDarkSearch.TextChanged
        ApplyDarkGridFilter()
    End Sub

    Private Sub cmbStatusFilter_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles cmbStatusFilter.SelectedIndexChanged
        ApplyDarkGridFilter()
    End Sub

    Private Sub btnDeleteRow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteRow.Click
        If dgvDarkGrid.SelectedRows.Count > 0 Then
            Dim confirm As DialogResult = MessageBox.Show("Are you sure you want to delete this student record?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If confirm = DialogResult.Yes Then
                Dim selectedRow As DataGridViewRow = dgvDarkGrid.SelectedRows(0)
                Dim id As String = If(selectedRow.Cells(0).Value IsNot Nothing, selectedRow.Cells(0).Value.ToString(), "")

                ' Delete from local XML database
                DatabaseHelper.DeleteStudent(id)

                If scoreDatabase.ContainsKey(id.ToLower()) Then scoreDatabase.Remove(id.ToLower())

                Dim liveRow As DataGridViewRow = FindRowByID(dgvLiveRoster, id)
                If liveRow IsNot Nothing Then dgvLiveRoster.Rows.Remove(liveRow)

                dgvDarkGrid.Rows.Remove(selectedRow)
                MessageBox.Show("Student record deleted successfully from system.", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Else
            MessageBox.Show("Please select a full row in Tab 2 to delete.", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    ' --- FILE EXPORT, IMPORT, EXCEL & EXIT ---

    Private Sub btnExportExcel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        If dgvDarkGrid.Rows.Count = 0 Then
            MessageBox.Show("No student records available to export.", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If

        Dim filePath As String = Path.Combine(Application.StartupPath, "GradeBook_Report.csv")

        Try
            Dim writer As New StreamWriter(filePath, False, System.Text.Encoding.UTF8)
            writer.WriteLine("Student ID,Student Name,Course,Grade,Status")

            For Each row As DataGridViewRow In dgvDarkGrid.Rows
                If Not row.IsNewRow AndAlso row.Visible Then
                    Dim id As String = If(row.Cells(0).Value IsNot Nothing, row.Cells(0).Value.ToString(), "")
                    Dim name As String = If(row.Cells(1).Value IsNot Nothing, row.Cells(1).Value.ToString(), "")
                    Dim course As String = If(row.Cells(2).Value IsNot Nothing, row.Cells(2).Value.ToString(), "")
                    Dim grade As String = If(row.Cells(3).Value IsNot Nothing, row.Cells(3).Value.ToString(), "")
                    Dim status As String = If(row.Cells(4).Value IsNot Nothing, row.Cells(4).Value.ToString(), "")

                    writer.WriteLine(String.Format("""{0}"",""{1}"",""{2}"",""{3}"",""{4}""", id, name, course, grade, status))
                End If
            Next

            writer.Close()

            If File.Exists(filePath) Then
                Process.Start(filePath)
            End If
        Catch ex As Exception
            MessageBox.Show("Failed to open data in Excel: " & ex.Message, "Export Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoad.Click
        Dim ofd As New OpenFileDialog()
        ofd.Filter = "GradeBook Pro Files (*.dmb)|*.dmb"

        If ofd.ShowDialog() = DialogResult.OK Then
            Try
                Dim reader As New StreamReader(ofd.FileName)
                Dim isHeader As Boolean = True

                dgvLiveRoster.Rows.Clear()
                dgvDarkGrid.Rows.Clear()
                scoreDatabase.Clear()

                While Not reader.EndOfStream
                    Dim line As String = reader.ReadLine()
                    If isHeader Then
                        isHeader = False
                        Continue While
                    End If
                    If String.IsNullOrWhiteSpace(line) Then Continue While

                    Dim fields() As String = line.Split(","c)
                    If fields.Length >= 9 Then
                        AddOrUpdateStudentRecord(fields(0).Trim(), fields(1).Trim(), fields(2).Trim(), _
                                                 Convert.ToDouble(fields(3)), Convert.ToDouble(fields(4)), _
                                                 Convert.ToDouble(fields(5)), Convert.ToDouble(fields(6)), _
                                                 Convert.ToDouble(fields(7)), Convert.ToDouble(fields(8)))
                    End If
                End While

                reader.Close()
                MessageBox.Show("Database loaded successfully into both tabs!", "Import Complete", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Catch ex As Exception
                MessageBox.Show("Load error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        If MessageBox.Show("Exit application?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            Application.Exit()
        End If
    End Sub

    Private Sub Form1_FormClosed(ByVal sender As Object, ByVal e As FormClosedEventArgs) Handles Me.FormClosed
        Application.Exit()
    End Sub

    Private Sub TabControl1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabControl1.SelectedIndexChanged

    End Sub
    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub
    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub
    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click

    End Sub
End Class