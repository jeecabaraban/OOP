﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.txtSearchRoster = New System.Windows.Forms.GroupBox()
        Me.dgvLiveRoster = New System.Windows.Forms.DataGridView()
        Me.colStudentID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colStudentName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCourse = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colGrade = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colStatus = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.grpStudentInfo = New System.Windows.Forms.GroupBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtProjectMax = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cmbCourse = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtExamMax = New System.Windows.Forms.TextBox()
        Me.lblCourse = New System.Windows.Forms.Label()
        Me.txtProjectScore = New System.Windows.Forms.TextBox()
        Me.txtQuizMax = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtStudentName = New System.Windows.Forms.TextBox()
        Me.lblStudentName = New System.Windows.Forms.Label()
        Me.txtStudentID = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblStudentID = New System.Windows.Forms.Label()
        Me.txtExamScore = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtQuizScore = New System.Windows.Forms.TextBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnLoad = New System.Windows.Forms.Button()
        Me.txtDarkSearch = New System.Windows.Forms.TextBox()
        Me.cmbStatusFilter = New System.Windows.Forms.ComboBox()
        Me.dgvDarkGrid = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.btnDeleteRow = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.txtSearchRoster.SuspendLayout()
        CType(Me.dgvLiveRoster, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpStudentInfo.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.dgvDarkGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.Label1.Font = New System.Drawing.Font("Microsoft Uighur", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DimGray
        Me.Label1.Location = New System.Drawing.Point(378, 50)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(145, 23)
        Me.Label1.TabIndex = 18
        Me.Label1.Text = "ADVANCED DASHBOARD"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.Label2.Font = New System.Drawing.Font("Microsoft New Tai Lue", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.DimGray
        Me.Label2.Location = New System.Drawing.Point(324, 15)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(249, 35)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "GRADING SYSTEM"
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.TextBox1.Location = New System.Drawing.Point(0, 4)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(919, 82)
        Me.TextBox1.TabIndex = 16
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(12, 93)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(895, 508)
        Me.TabControl1.TabIndex = 15
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.txtSearchRoster)
        Me.TabPage1.Controls.Add(Me.grpStudentInfo)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(887, 482)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Grade Entry"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'txtSearchRoster
        '
        Me.txtSearchRoster.BackColor = System.Drawing.Color.Bisque
        Me.txtSearchRoster.Controls.Add(Me.dgvLiveRoster)
        Me.txtSearchRoster.Location = New System.Drawing.Point(24, 279)
        Me.txtSearchRoster.Name = "txtSearchRoster"
        Me.txtSearchRoster.Size = New System.Drawing.Size(837, 180)
        Me.txtSearchRoster.TabIndex = 19
        Me.txtSearchRoster.TabStop = False
        Me.txtSearchRoster.Text = "Current Class Roster"
        '
        'dgvLiveRoster
        '
        Me.dgvLiveRoster.AllowUserToOrderColumns = True
        Me.dgvLiveRoster.BackgroundColor = System.Drawing.Color.Bisque
        Me.dgvLiveRoster.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvLiveRoster.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colStudentID, Me.colStudentName, Me.colCourse, Me.colGrade, Me.colStatus})
        Me.dgvLiveRoster.Location = New System.Drawing.Point(21, 31)
        Me.dgvLiveRoster.Name = "dgvLiveRoster"
        Me.dgvLiveRoster.Size = New System.Drawing.Size(794, 143)
        Me.dgvLiveRoster.TabIndex = 26
        '
        'colStudentID
        '
        Me.colStudentID.HeaderText = "Student ID"
        Me.colStudentID.Name = "colStudentID"
        Me.colStudentID.Width = 150
        '
        'colStudentName
        '
        Me.colStudentName.HeaderText = "Student Name"
        Me.colStudentName.Name = "colStudentName"
        Me.colStudentName.Width = 250
        '
        'colCourse
        '
        Me.colCourse.HeaderText = "Course"
        Me.colCourse.Name = "colCourse"
        Me.colCourse.Width = 120
        '
        'colGrade
        '
        Me.colGrade.HeaderText = "Grade"
        Me.colGrade.Name = "colGrade"
        Me.colGrade.Width = 120
        '
        'colStatus
        '
        Me.colStatus.HeaderText = "Status"
        Me.colStatus.Name = "colStatus"
        Me.colStatus.Width = 130
        '
        'grpStudentInfo
        '
        Me.grpStudentInfo.BackColor = System.Drawing.Color.Bisque
        Me.grpStudentInfo.Controls.Add(Me.btnCalculate)
        Me.grpStudentInfo.Controls.Add(Me.btnClear)
        Me.grpStudentInfo.Controls.Add(Me.Label9)
        Me.grpStudentInfo.Controls.Add(Me.txtProjectMax)
        Me.grpStudentInfo.Controls.Add(Me.Label7)
        Me.grpStudentInfo.Controls.Add(Me.cmbCourse)
        Me.grpStudentInfo.Controls.Add(Me.Label10)
        Me.grpStudentInfo.Controls.Add(Me.txtExamMax)
        Me.grpStudentInfo.Controls.Add(Me.lblCourse)
        Me.grpStudentInfo.Controls.Add(Me.txtProjectScore)
        Me.grpStudentInfo.Controls.Add(Me.txtQuizMax)
        Me.grpStudentInfo.Controls.Add(Me.Label8)
        Me.grpStudentInfo.Controls.Add(Me.txtStudentName)
        Me.grpStudentInfo.Controls.Add(Me.lblStudentName)
        Me.grpStudentInfo.Controls.Add(Me.txtStudentID)
        Me.grpStudentInfo.Controls.Add(Me.Label6)
        Me.grpStudentInfo.Controls.Add(Me.lblStudentID)
        Me.grpStudentInfo.Controls.Add(Me.txtExamScore)
        Me.grpStudentInfo.Controls.Add(Me.Label3)
        Me.grpStudentInfo.Controls.Add(Me.txtQuizScore)
        Me.grpStudentInfo.Location = New System.Drawing.Point(24, 31)
        Me.grpStudentInfo.Name = "grpStudentInfo"
        Me.grpStudentInfo.Size = New System.Drawing.Size(837, 229)
        Me.grpStudentInfo.TabIndex = 18
        Me.grpStudentInfo.TabStop = False
        Me.grpStudentInfo.Text = "Student & Score Inputs"
        '
        'btnCalculate
        '
        Me.btnCalculate.BackColor = System.Drawing.Color.White
        Me.btnCalculate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculate.ForeColor = System.Drawing.Color.YellowGreen
        Me.btnCalculate.Location = New System.Drawing.Point(533, 179)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(106, 32)
        Me.btnCalculate.TabIndex = 26
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = False
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.Color.White
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.ForeColor = System.Drawing.Color.Red
        Me.btnClear.Location = New System.Drawing.Point(682, 179)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(106, 32)
        Me.btnClear.TabIndex = 25
        Me.btnClear.Text = "Clear Form"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft YaHei UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(412, 128)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(84, 16)
        Me.Label9.TabIndex = 19
        Me.Label9.Text = "Project (20%) :"
        '
        'txtProjectMax
        '
        Me.txtProjectMax.Location = New System.Drawing.Point(708, 126)
        Me.txtProjectMax.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtProjectMax.Name = "txtProjectMax"
        Me.txtProjectMax.Size = New System.Drawing.Size(80, 20)
        Me.txtProjectMax.TabIndex = 22
        Me.txtProjectMax.Text = "100"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft YaHei UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(412, 87)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(75, 16)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "Exam (50%) :"
        '
        'cmbCourse
        '
        Me.cmbCourse.FormattingEnabled = True
        Me.cmbCourse.Items.AddRange(New Object() {"CS-101", "BSIT-201", "BSCS-301"})
        Me.cmbCourse.Location = New System.Drawing.Point(125, 125)
        Me.cmbCourse.Name = "cmbCourse"
        Me.cmbCourse.Size = New System.Drawing.Size(165, 21)
        Me.cmbCourse.TabIndex = 10
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft YaHei UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(655, 127)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(13, 16)
        Me.Label10.TabIndex = 21
        Me.Label10.Text = "/"
        '
        'txtExamMax
        '
        Me.txtExamMax.Location = New System.Drawing.Point(708, 85)
        Me.txtExamMax.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtExamMax.Name = "txtExamMax"
        Me.txtExamMax.Size = New System.Drawing.Size(80, 20)
        Me.txtExamMax.TabIndex = 17
        Me.txtExamMax.Text = "100"
        '
        'lblCourse
        '
        Me.lblCourse.AutoSize = True
        Me.lblCourse.Font = New System.Drawing.Font("Microsoft YaHei UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCourse.Location = New System.Drawing.Point(33, 128)
        Me.lblCourse.Name = "lblCourse"
        Me.lblCourse.Size = New System.Drawing.Size(50, 16)
        Me.lblCourse.TabIndex = 8
        Me.lblCourse.Text = "Course :"
        '
        'txtProjectScore
        '
        Me.txtProjectScore.Location = New System.Drawing.Point(533, 125)
        Me.txtProjectScore.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtProjectScore.Name = "txtProjectScore"
        Me.txtProjectScore.Size = New System.Drawing.Size(80, 20)
        Me.txtProjectScore.TabIndex = 20
        Me.txtProjectScore.Text = "0"
        '
        'txtQuizMax
        '
        Me.txtQuizMax.Location = New System.Drawing.Point(708, 45)
        Me.txtQuizMax.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtQuizMax.Name = "txtQuizMax"
        Me.txtQuizMax.Size = New System.Drawing.Size(80, 20)
        Me.txtQuizMax.TabIndex = 13
        Me.txtQuizMax.Text = "100"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft YaHei UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(655, 87)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(13, 16)
        Me.Label8.TabIndex = 18
        Me.Label8.Text = "/"
        '
        'txtStudentName
        '
        Me.txtStudentName.Location = New System.Drawing.Point(125, 84)
        Me.txtStudentName.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtStudentName.Name = "txtStudentName"
        Me.txtStudentName.Size = New System.Drawing.Size(165, 20)
        Me.txtStudentName.TabIndex = 7
        '
        'lblStudentName
        '
        Me.lblStudentName.AutoSize = True
        Me.lblStudentName.Font = New System.Drawing.Font("Microsoft YaHei UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStudentName.Location = New System.Drawing.Point(33, 87)
        Me.lblStudentName.Name = "lblStudentName"
        Me.lblStudentName.Size = New System.Drawing.Size(67, 16)
        Me.lblStudentName.TabIndex = 6
        Me.lblStudentName.Text = "Full Name :"
        '
        'txtStudentID
        '
        Me.txtStudentID.Location = New System.Drawing.Point(125, 45)
        Me.txtStudentID.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtStudentID.Name = "txtStudentID"
        Me.txtStudentID.Size = New System.Drawing.Size(165, 20)
        Me.txtStudentID.TabIndex = 1
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft YaHei UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(655, 52)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(13, 16)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "/"
        '
        'lblStudentID
        '
        Me.lblStudentID.AutoSize = True
        Me.lblStudentID.Font = New System.Drawing.Font("Microsoft YaHei UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStudentID.Location = New System.Drawing.Point(33, 50)
        Me.lblStudentID.Name = "lblStudentID"
        Me.lblStudentID.Size = New System.Drawing.Size(69, 16)
        Me.lblStudentID.TabIndex = 0
        Me.lblStudentID.Text = "Student ID :"
        '
        'txtExamScore
        '
        Me.txtExamScore.Location = New System.Drawing.Point(533, 85)
        Me.txtExamScore.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtExamScore.Name = "txtExamScore"
        Me.txtExamScore.Size = New System.Drawing.Size(80, 20)
        Me.txtExamScore.TabIndex = 16
        Me.txtExamScore.Text = "0"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft YaHei UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(412, 47)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(71, 16)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Quiz (30%) :"
        '
        'txtQuizScore
        '
        Me.txtQuizScore.Location = New System.Drawing.Point(533, 45)
        Me.txtQuizScore.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtQuizScore.Name = "txtQuizScore"
        Me.txtQuizScore.Size = New System.Drawing.Size(80, 20)
        Me.txtQuizScore.TabIndex = 11
        Me.txtQuizScore.Text = "0"
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.Bisque
        Me.TabPage2.Controls.Add(Me.btnSave)
        Me.TabPage2.Controls.Add(Me.btnExit)
        Me.TabPage2.Controls.Add(Me.btnLoad)
        Me.TabPage2.Controls.Add(Me.txtDarkSearch)
        Me.TabPage2.Controls.Add(Me.cmbStatusFilter)
        Me.TabPage2.Controls.Add(Me.dgvDarkGrid)
        Me.TabPage2.Controls.Add(Me.btnDeleteRow)
        Me.TabPage2.Controls.Add(Me.Label5)
        Me.TabPage2.Controls.Add(Me.Label4)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(887, 482)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Detailed Analysis"
        '
        'btnSave
        '
        Me.btnSave.BackColor = System.Drawing.Color.White
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.ForeColor = System.Drawing.Color.YellowGreen
        Me.btnSave.Location = New System.Drawing.Point(46, 335)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(131, 32)
        Me.btnSave.TabIndex = 33
        Me.btnSave.Text = "Export Records"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.White
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.Red
        Me.btnExit.Location = New System.Drawing.Point(709, 385)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(131, 32)
        Me.btnExit.TabIndex = 32
        Me.btnExit.Text = "Exit Application"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'btnLoad
        '
        Me.btnLoad.BackColor = System.Drawing.Color.White
        Me.btnLoad.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLoad.ForeColor = System.Drawing.Color.YellowGreen
        Me.btnLoad.Location = New System.Drawing.Point(46, 385)
        Me.btnLoad.Name = "btnLoad"
        Me.btnLoad.Size = New System.Drawing.Size(131, 32)
        Me.btnLoad.TabIndex = 31
        Me.btnLoad.Text = "Import Records"
        Me.btnLoad.UseVisualStyleBackColor = False
        '
        'txtDarkSearch
        '
        Me.txtDarkSearch.Location = New System.Drawing.Point(142, 55)
        Me.txtDarkSearch.Name = "txtDarkSearch"
        Me.txtDarkSearch.Size = New System.Drawing.Size(257, 20)
        Me.txtDarkSearch.TabIndex = 30
        '
        'cmbStatusFilter
        '
        Me.cmbStatusFilter.FormattingEnabled = True
        Me.cmbStatusFilter.Location = New System.Drawing.Point(583, 55)
        Me.cmbStatusFilter.Name = "cmbStatusFilter"
        Me.cmbStatusFilter.Size = New System.Drawing.Size(257, 21)
        Me.cmbStatusFilter.TabIndex = 29
        '
        'dgvDarkGrid
        '
        Me.dgvDarkGrid.AllowUserToOrderColumns = True
        Me.dgvDarkGrid.BackgroundColor = System.Drawing.Color.Bisque
        Me.dgvDarkGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvDarkGrid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5})
        Me.dgvDarkGrid.Location = New System.Drawing.Point(46, 137)
        Me.dgvDarkGrid.Name = "dgvDarkGrid"
        Me.dgvDarkGrid.Size = New System.Drawing.Size(794, 143)
        Me.dgvDarkGrid.TabIndex = 28
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.HeaderText = "Student ID"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Width = 150
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.HeaderText = "Student Name"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 250
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.HeaderText = "Course"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 120
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.HeaderText = "Grade"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Width = 120
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.HeaderText = "Status"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.Width = 130
        '
        'btnDeleteRow
        '
        Me.btnDeleteRow.BackColor = System.Drawing.Color.White
        Me.btnDeleteRow.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDeleteRow.ForeColor = System.Drawing.Color.Red
        Me.btnDeleteRow.Location = New System.Drawing.Point(677, 335)
        Me.btnDeleteRow.Name = "btnDeleteRow"
        Me.btnDeleteRow.Size = New System.Drawing.Size(163, 32)
        Me.btnDeleteRow.TabIndex = 27
        Me.btnDeleteRow.Text = "Delete Selected Row"
        Me.btnDeleteRow.UseVisualStyleBackColor = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(512, 58)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(32, 13)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Filter:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(43, 58)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(74, 13)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Search Table:"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(919, 604)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.txtSearchRoster.ResumeLayout(False)
        CType(Me.dgvLiveRoster, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpStudentInfo.ResumeLayout(False)
        Me.grpStudentInfo.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.dgvDarkGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents txtSearchRoster As System.Windows.Forms.GroupBox
    Friend WithEvents dgvLiveRoster As System.Windows.Forms.DataGridView
    Friend WithEvents colStudentID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colStudentName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCourse As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colGrade As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colStatus As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents grpStudentInfo As System.Windows.Forms.GroupBox
    Friend WithEvents btnCalculate As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtProjectMax As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cmbCourse As System.Windows.Forms.ComboBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtExamMax As System.Windows.Forms.TextBox
    Friend WithEvents lblCourse As System.Windows.Forms.Label
    Friend WithEvents txtProjectScore As System.Windows.Forms.TextBox
    Friend WithEvents txtQuizMax As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtStudentName As System.Windows.Forms.TextBox
    Friend WithEvents lblStudentName As System.Windows.Forms.Label
    Friend WithEvents txtStudentID As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents lblStudentID As System.Windows.Forms.Label
    Friend WithEvents txtExamScore As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtQuizScore As System.Windows.Forms.TextBox
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents btnLoad As System.Windows.Forms.Button
    Friend WithEvents txtDarkSearch As System.Windows.Forms.TextBox
    Friend WithEvents cmbStatusFilter As System.Windows.Forms.ComboBox
    Friend WithEvents dgvDarkGrid As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents btnDeleteRow As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label

End Class
