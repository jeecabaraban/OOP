﻿Public MustInherit Class Assessment
    Protected score As Double
    Protected maxScore As Double
    Protected weight As Double

    Public Sub New(ByVal score As Double, ByVal maxScore As Double, ByVal weight As Double)
        Me.score = score
        Me.maxScore = If(maxScore > 0, maxScore, 100)
        Me.weight = weight
    End Sub

    Public Function CalculateWeightedScore() As Double
        If maxScore = 0 Then Return 0
        Return (score / maxScore) * weight
    End Function
End Class

Public Class QuizAssessment
    Inherits Assessment

    Public Sub New(ByVal score As Double, ByVal maxScore As Double, ByVal weight As Double)
        MyBase.New(score, maxScore, weight)
    End Sub
End Class

Public Class ExamAssessment
    Inherits Assessment

    Public Sub New(ByVal score As Double, ByVal maxScore As Double, ByVal weight As Double)
        MyBase.New(score, maxScore, weight)
    End Sub
End Class

Public Class ProjectAssessment
    Inherits Assessment

    Public Sub New(ByVal score As Double, ByVal maxScore As Double, ByVal weight As Double)
        MyBase.New(score, maxScore, weight)
    End Sub
End Class