﻿Public Class Form2

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Mask password input with asterisks
        txtPassword.PasswordChar = "*"c
        txtUsername.Focus()
    End Sub

    Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        Dim username As String = txtUsername.Text.Trim()
        Dim password As String = txtPassword.Text.Trim()

        ' Validate inputs
        If username = "" OrElse password = "" Then
            MessageBox.Show("Please enter both username and password.", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            If username = "" Then
                txtUsername.Focus()
            Else
                txtPassword.Focus()
            End If
            Exit Sub
        End If

        ' Authenticate credentials (user: admin | pass: 041207)
        If username.Equals("admin", StringComparison.OrdinalIgnoreCase) AndAlso password = "041207" Then
            MessageBox.Show("Login successful! Opening GradeBook Dashboard...", "Access Granted", MessageBoxButtons.OK, MessageBoxIcon.Information)

            ' Launch Form1 (Main Dashboard)
            Dim mainForm As New Form1()
            mainForm.Show()

            ' Hide Form2 (Login Window)
            Me.Hide()
        Else
            MessageBox.Show("Invalid Username or Password. Please try again.", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtPassword.Clear()
            txtUsername.Focus()
            txtUsername.SelectAll()
        End If
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        If MessageBox.Show("Are you sure you want to exit the application?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            Application.Exit()
        End If
    End Sub

    Private Sub Form2_FormClosed(ByVal sender As Object, ByVal e As FormClosedEventArgs) Handles Me.FormClosed
        Application.Exit()
    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub
End Class