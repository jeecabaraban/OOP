﻿Imports System.Collections.Generic

Public Class Course
    Public Property CourseCode As String
    Public Property CourseTitle As String
    Public Property GradeRecords As List(Of Grade)

    Public Sub New(ByVal code As String, ByVal title As String)
        Me.CourseCode = code
        Me.CourseTitle = title
        Me.GradeRecords = New List(Of Grade)()
    End Sub

    Public Sub AddGradeRecord(ByVal g As Grade)
        GradeRecords.Add(g)
    End Sub
End Class