﻿Imports System.Collections.Generic

Public Class Grade
    Public Property Student As Student
    Private assessments As New List(Of Assessment)()

    Public Sub New(ByVal student As Student)
        Me.Student = student
    End Sub

    Public Sub AddAssessment(ByVal assessment As Assessment)
        assessments.Add(assessment)
    End Sub

    Public Function ComputeFinal() As Double
        Dim total As Double = 0
        For Each item As Assessment In assessments
            total += item.CalculateWeightedScore()
        Next
        Return total
    End Function

    Public Function GetEquivalent(ByVal finalScore As Double) As String
        If finalScore >= 90 Then Return "A"
        If finalScore >= 80 Then Return "B"
        If finalScore >= 70 Then Return "C"
        If finalScore >= 60 Then Return "D"
        Return "F"
    End Function

    Public Function IsPassed(ByVal finalScore As Double) As String
        If finalScore >= 60 Then
            Return "PASSED"
        Else
            Return "FAILED"
        End If
    End Function
End Class